
import Controller.TaxController;

public class main {

    public static void main(String[] args) {
        TaxController tx = new TaxController();
        tx.run();
    }
}
